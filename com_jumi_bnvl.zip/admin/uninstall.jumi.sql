DROP TABLE IF EXISTS `#__jumi`;

DELETE FROM `#__menu` where link LIKE 'index.php?option=com_jumi%';