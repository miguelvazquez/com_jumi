<?php
/**
* @version   $Id$
* @package   Jumi
* @copyright (C) 2008 - 2013 Simon Poghosyan
* @license   GNU/GPL v3 http://www.gnu.org/licenses/gpl.html
*/

defined('_JEXEC') or die('Restricted access');